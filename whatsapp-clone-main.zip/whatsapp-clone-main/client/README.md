# Whatsapp Clone - Fullstack Projects

![](whatsapp-clone.gif)

### Demo - Deployed over Github Pages 
https://ayushkul.github.io/whatsapp-clone

### Full development Tutorial 
[Youtube Tutorial - The Indian Dev](https://www.youtube.com/watch?v=_UXycMmVYj0)

### Libraries used
* `styled-components`
* `axios`
* `react-scripts`

### Whom do I talk to? ###

* AyushK : [The Indian Dev](https://www.instagram.com/theindiandev)

### How can I appreciate this repo? ###

* By giving this repo a 🌟
* By Subscribing : [The Indian Dev](https://www.youtube.com/c/theindiandev) at Youtube
* By Following : [The Indian Dev](https://www.instagram.com/theindiandev) at Instagram

